package examples.process.model;


public class ServiceContext {

}
