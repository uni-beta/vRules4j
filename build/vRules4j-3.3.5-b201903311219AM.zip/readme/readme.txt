It is java technical related and can only be sued for validating the java object instance.The advantages of this software are following:

1. Easy to use.
2. High performance.
3. The validation predicate can support the java standard syntax.
4. With thread-safe mechanism.
5. The configuration rules is easy.
6. It is free.


An useful Java Object Validation rule engine, which can be used for valiadating the java object instance by the rule congiguration in a seperated outside file. 

vRules is free software; you can redistribute it and/or modify it under 
the terms of Version 2.0 Apache License as published by  the Free Software 
Foundation.

What is vRules4j?
An open source project which is initiated individually
Distributed under Apache License 2.0 freely
Distributed in the hope that it will be useful not only for the development founder but also for all individuals and organizations who is in need.
Ideals & Vision
Focus on analysis in the Java Bean object validation, be the best analysis/validation java engine tool all around the java world.

Advantage of vRules4j?

High performance, as fast as local JVM binary class executing speed. 
Configuration rules are of wonderful readability and perfect maintainability 
Full-featured and powerful 
Arbitrary complexity analysis of the depth of recursion supported
Rules are of object-oriented designed
Object inheritance complex validation supported
Multiple attributes associated validation supported
User-defined of business methods can be invoked from outside
XPath accurate location for where error happened 
Standard java language predicate grammar supported for rules�� configuration
Rules�� file can be reused or reorganized  via ��includes�� function
vRules4j-Digester tools is built-in to help generate the corresponding validation rules file. 
Easy to use, and very low coupling with local program
ErrorObject can be customized to return when the specified rule validated failure. 
vRules4j can also be used into web container as a independence middleware
I18N supported
