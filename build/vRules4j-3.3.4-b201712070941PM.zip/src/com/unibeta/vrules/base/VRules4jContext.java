package com.unibeta.vrules.base;


public class VRules4jContext {
    
    private String name;
    private String className;
    
    public String getClassName() {
    
        return className;
    }
    
    public void setClassName(String className) {
    
        this.className = className;
    }
    
    public String getName() {
    
        return name;
    }
    
    public void setName(String name) {
    
        this.name = name;
    }

}
